someVarWithoutLetOrConst=0; // u shouldnt
let someVar; // without assignment it is undefined
let x = "Tuesday" //need to use let to declare
x = 3; //with let you can point to something else
x++;
++x;

let index = 0;
while (index < 5) {
    let y = index++;
    console.log('y', y)
}


if (x=="3") {
    console.log("string and number 3 are equal")
//value is converted from number to string - coercion
}
else {
    console.log("no way man - strict equality")
}


const person = {name:"Fred", age:49}
person.name = "Toni"
console.log('person', person)
// person = {name:"Toni"}