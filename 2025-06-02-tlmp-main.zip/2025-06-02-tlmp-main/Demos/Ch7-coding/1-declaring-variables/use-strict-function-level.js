/* eslint-disable no-undef */
//  'use strict';
function doStuff() {
  // 'use strict';
  // Assuming no global variable mistypeVariable exists
  mistypeVariable = 17;  // this line throws a ReferenceError due to the
                        // variable not declared with let or const
  console.log('mistypeVariable', mistypeVariable);
}

doStuff();

function doSum(a,b) {
  'use strict';
  c = a + b;
}

doSum(2,3);
console.log('c', c);

let x = 'Hello ${name}';
console.log('x', x);

