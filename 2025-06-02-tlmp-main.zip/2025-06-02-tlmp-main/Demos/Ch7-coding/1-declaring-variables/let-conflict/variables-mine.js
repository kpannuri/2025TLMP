let myFavoriteMusician = 'Les Claypool';

console.log('myFavoriteMusician :>> ', myFavoriteMusician);