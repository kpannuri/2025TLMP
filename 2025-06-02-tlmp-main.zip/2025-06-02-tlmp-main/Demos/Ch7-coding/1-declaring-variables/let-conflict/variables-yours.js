/* eslint-disable no-unused-vars */
let myFavoriteMusician = 'Natalie Cole';