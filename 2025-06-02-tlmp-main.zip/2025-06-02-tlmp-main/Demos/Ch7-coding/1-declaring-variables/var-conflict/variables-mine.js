/* eslint-disable no-unused-vars */
var myFavoriteMusician = 'Les Claypool';
