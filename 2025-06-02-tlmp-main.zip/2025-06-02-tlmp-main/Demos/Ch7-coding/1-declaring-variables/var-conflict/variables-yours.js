/* eslint-disable no-unused-vars */
var myFavoriteMusician = 'Natalie Cole';