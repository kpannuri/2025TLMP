// for screenshot purposes, let pi so no error

let changingValue = true;
let pi = 3.14;  
let myMother = {
    name: 'Mary',
    age: 82
};


changingValue = false;
pi = 3.1415926535;
myMother = {
    name: 'Mary',
    age: 82
};
myMother.age++;

console.log('values', changingValue, pi);
