/* eslint-disable no-undef */
'use strict';
                       // Assuming no global variable mistypeVariable exists
mistypeVariable = 17;  // this line throws a ReferenceError due to 
                      // variable not declared with let or const
console.log('mistypeVariable', mistypeVariable)     ; 