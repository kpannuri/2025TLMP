let x = 'Tuesday'; 
x = 3;
if (x=="3") {console.log('x', x);}
