let [first, last] = ['Les','Claypool'];
console.log(first, last);
//instead of 
// data = ['Les','Claypool'];
// let first = data[0]
// let last = data[1]
