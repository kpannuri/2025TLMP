{
    const now =  Date();
    console.log('now', typeof now)
}

{
    const now = new Date();
    console.log('now', typeof now)
}