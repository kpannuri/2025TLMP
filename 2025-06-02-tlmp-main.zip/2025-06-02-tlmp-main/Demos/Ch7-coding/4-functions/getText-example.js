let getText = function () {
  return "Hello";
}

// let getText = function () {
//   return "Hello";
// }

getText();


//if ESLint extension is enabled, and you have run "npm install"
//you will see a red squiggly line on line 5