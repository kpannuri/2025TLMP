function multiply (a, b) {
  if ((typeof b) != 'undefined') {
      //no op
  }
  else {
      b = 2;
  }

  b = ((typeof b) != 'undefined') ? b : 2;

  return a * b;
}

console.log('multiply(2)', multiply(2));
console.log('multiply(2,3)', multiply(2,3));