function greet () {
    console.log("Hello");
}

// function greet () {
//     console.log("Bonjour");
// }

greet()

//there is a better way!

let newGreet = function() {
    console.log("Hello");
}

// let newGreet = function() {
//     console.log("Bonjour");
// }

newGreet()