function printStars() {
  console.log("**********");
}

printStars();
console.log(printStars());  // undefined

function add(a, b) {
  console.log(typeof(a));
  console.log(typeof(b));
  return a + b;
}

console.log(add(3,4));      // 7
console.log(add(3));        // Nan
console.log(add(4,5,5,6));  // 9
console.log(add());         // Nan

function multiply(a, b=2) {
  let answer = a * b;
  return answer;
}  

console.log(multiply(4));   // 8
console.log(multiply(4,5)); // 20
console.log(multiply());    // Nan

function add(a,b) {
  return a - b;
}

console.log(add(3,4));      // 
console.log(add(3));        // 
console.log(add(4,5,5,6));  // 
console.log(add());         // 

// function display() {
//     console.log("display function");
// }


let display = function() {
  console.log("display function");
}

display();

// let display = function() {
//     console.log("another one");
// }



