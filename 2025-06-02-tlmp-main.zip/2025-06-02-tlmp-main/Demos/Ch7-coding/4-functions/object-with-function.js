const person = {
  firstName: "Carole",
  lastName: "King",
  fullName: function() {
    return `${this.firstName} ${this.lastName}`;
  }
};

console.log('person.fullName()', person.fullName());