function add(a,b) {
        return a + b;
}

// does nothing with returned value
add(3,4); 

//prints returned value
console.log('3 + 4=', add(3,4));  

