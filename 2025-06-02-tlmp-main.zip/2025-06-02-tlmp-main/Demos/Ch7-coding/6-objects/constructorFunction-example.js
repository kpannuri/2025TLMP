// ctor function
function Square(width) {
  this.width = width;
  this.area = function() {
      return this.width * this.width;
  }
}

let square1 = new Square(6);
console.log(square1.area());

let square2 = new Square(7);
console.log(square2.area());

// if new operator is not used
// keyword this will pertain to the window object
// always use the new operator .......
// let square3 = Square(6);
// console.log(square3.width);

//BETTER SOLUTION
// attributes/properties
function BetterSquare(width) {
  this.width = width;   
}

// define function using prototype
BetterSquare.prototype.area = function() {
  return this.width * this.width;
}

let better1 = new BetterSquare(5);
console.log(better1.area());

let better2 = new BetterSquare(11);
console.log(better2.area());
// Only once instance of area() function