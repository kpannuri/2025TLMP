
function printB() {
    console.log("B");
}
// Now call above function every 2 seconds
setInterval(printB, 2000);