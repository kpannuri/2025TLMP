console.log("one");

printTwo();

console.log("three");

function printTwo() {
    console.log("two");
}

