/* Demonstrating execution order: */

console.log("Hello");

setTimeout(function() {
	console.log("World!");
}, 2000);

setTimeout(()=> {
	console.log("Universe!");
}, 2000);

console.log("Last line");

/* Output:
   Hello
   Last Line
   [... 2 seconds pass ...]
   World!
   Universe!
*/


