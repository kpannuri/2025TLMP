//////////////////////////////////////////

/* Calling callbacks from within 
callbacks for sequential behaviour: */

let x = (Math.random()*100);
let y = (Math.random()*100);

setTimeout(() => {
	console.log("Hello");
}, x);

setTimeout(() => {
  console.log("World!");
}, y);

console.log('End of program reached');



