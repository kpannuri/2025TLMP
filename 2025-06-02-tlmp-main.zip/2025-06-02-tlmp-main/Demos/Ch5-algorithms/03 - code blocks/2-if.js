let x = new Date();
x = x.getDay();
//0 is Sunday... 6 is Saturday

let msg = "";

if (x==0) {
    msg ="It's Sunday";
}
else if (x==6) {
    msg ="It's Saturday";
}
else {
    msg ="It's a weekday";
}
console.log(msg)
