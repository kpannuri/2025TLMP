let correctlyGuessedLetter = "e";
let words = ["roach", "aisle", "quite"];
let nextGuess = "";

// Loop through the array backwards so we can 
// safely remove items while iterating
for (let index = words.length - 1; index >= 0; index--) {
    const element = words[index];
    if (element.includes(correctlyGuessedLetter)) {
        if (nextGuess === "") {
            nextGuess = element;
        }
        words.splice(index, 1); // Remove the word from the array
    }
}

console.log("Next guess:", nextGuess);
console.log("Remaining words:", words);
