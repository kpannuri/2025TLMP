let hour = Math.round((Math.random() * 19));
console.log(hour)
if (hour >= 12 && hour < 13) {
  console.log("It is lunch time")
}
else if (hour >= 8 && hour < 17) {
  console.log("class is in session")
}
else  {
  console.log("class is not in session")
}

