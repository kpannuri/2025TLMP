let x = 3;

{
//this is a code block
    let y = 4;
}

console.log(x);
// y is not reachable, not in scope
console.log(y); 