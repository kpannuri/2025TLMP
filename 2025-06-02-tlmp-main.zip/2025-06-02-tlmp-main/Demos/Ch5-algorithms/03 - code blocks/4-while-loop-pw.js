// Set the correct password
const correctPassword = 'yourpassword';
let keepTrying = true;

while (keepTrying) {
    // Ask the user to enter the password
    let password = prompt("Enter password:");

    // Check if the entered password matches the correct one
    if (password === correctPassword) {
        keepTrying = false;
    } else {
        alert("Incorrect password, try again.");
    }
}

console.log("Access granted.")
