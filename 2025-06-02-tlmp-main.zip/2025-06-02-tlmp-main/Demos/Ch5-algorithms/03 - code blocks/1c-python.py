x = 3

# Python uses indentation for block scope
# This block will not create a new scope as in JavaScript.

if True:
    y = 4  # y is defined within this block
    # y is still accessible outside this block

print(x)
# In Python, y is still accessible here, contrary to JavaScript's block scope.
print(y)
