x = 3

# This is a code block in 
# Python (defined by indentation)
if True:
    y = 4  
    # y is still accessible outside this block

print(x)  # 3
print(y)  # 4 – y is accessible here!
