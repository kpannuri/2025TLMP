let x = 2, y=5;

console.log('x<y', x<y);

let thing1 = "chicken";
let thing2 = "egg";

console.log('thing1<thing2', thing1<thing2);

console.log('thing1.length<thing2.length', thing1.length<thing2.length)