public class Demo {

  public static void main() {
    System.out.println("Hello");
  }

}

