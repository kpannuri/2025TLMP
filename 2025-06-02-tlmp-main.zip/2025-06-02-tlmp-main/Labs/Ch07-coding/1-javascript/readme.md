# Lab 7-1: JS variables

## Objectives

* Practice with JS variables
* Use console.log shortcut


## Steps

1. Create a `WIP/Lab6-1` folder
and in this folder create a file called `variables.js`.

1. Declare x and y, and assign the values as shown.
   
    ![Open in Preview mode to see this image](../screenshots/6-1-1-declare-x-y.png)

2. The following extension gives you the ability to quickly write `console.log()`. Confirm you see it in the extensions list. Always check by the author's name as some extensions are named similarly.

    ![Open in Preview mode to see this image](../screenshots/6-1-2-shortcuts.png)

1. Type `clg` and then hit **Tab.** then double quotes as shown. You can hit the End key to reach the end of the line and add the optional semicolon. 

    ![Open in Preview mode to see this image](../screenshots/6-1-clg.gif)

1. Create another statement in this was so that you have the following.

    ![Open in Preview mode to see this image](../screenshots/6-1-2b-more-clg.png)

1. View the following usage for using the shortcut `clo` to create a console.log that prints a string and a value. When you use the `clo + Tab` - you will have two blinking cursors. As you type you are completing both the string and the value to print.

    ![Open in Preview mode to see this image](../screenshots/6-1-clo.gif)

1. Use the `clo` shortcut to add the last two lines as shown.

    ![Open in Preview mode to see this image](../screenshots/6-1-2c-code-after-clo.png)


2. The Code Runner extension gives you the ability to quickly run JS code. Confirm you see it in Extensions as shown.

    ![Open in Preview mode to see this image](../screenshots/6-1-2b-runner.png)

3. Run your code by hitting the play button in the upper right as shown. You will see the output in the console.

    ![Open in Preview mode to see this image](../screenshots/6-1-2d-output.png)

    * With Code Runner, while looking at your variables.js code in the editor, you also right-click and choose Run Code 
    * Or, use the shortcut (Ctrl + Alt + N)


4. You can also run your code from the Terminal window - though you need to be in the right location. This extension gives you the ability to open a Terminal at the same location as the current file. Confirm you see it in the extensions list.

    ![Open in Preview mode to see this image](../screenshots/6-1-2g-open-terminal.png)

1. Click on your `variables.js` file so that it is the active file, and then open the command palette using `Control+Shift+P` - then start typing "terminal here" if you do not see it at the top of the list. 
   
    ![Open in Preview mode to see this image](../screenshots/6-1-2h-open-terminal.png)

1. Choose Terminal Here and the Terminal Window opens at the correct location. From here you can run the program by using `node`, a space, then start typing the name of the file, and hit `Tab` to autocomplete, then hit Enter to run.

    ![Open in Preview mode to see this image](../screenshots/6-1-2i-use-node.png)

    ![Open in preview mode to see image](../screenshots/6-1-2j-output.png)


2. Note: another way to reach the terminal at the correct location is to right click a file you wish to run, and choose Open in Integrated Terminal

    ![Open in preview mode to see image](../screenshots/1-open-in-terminal.png)

 
7.  Add this to your code to use the `+` operator with x and y. Use the `clo` shortcut to print.

    ![Open in preview mode to see image](../screenshots/6-1-3-more-code.png)

1. Run your code using one of the above methods. Are you getting back what you expected?

    ![Open in preview mode to see image](../screenshots/6-1-3-output-z.png)

    When using the `+` with string and number types, the number is converted to a string and then concatenated.

2. Add the following which uses the backtick \` and concatenates using the syntax `${}`. Use the `clg` shortcut to print the value of z.

    ![Open in preview mode to see image](../screenshots/6-1-3-more-code3.png)

1. Run your code using one of the above methods. Your output should look as shown with values substituted and spaces preserved.

    ![Open in preview mode to see image](../screenshots/6-1-3-output-z2.png)


3. Add this code which uses the post increment operator. Use the **clg** and **clo** shortcuts for the print statements. 
    ![Open in preview mode to see image](../screenshots/6-1-3-more-code2.png)

1. Run your code. Are you getting back what you expected? Both `x++` and `++x` increment x by 1, and when you used in an assignment have different outcomes.

    ![Open in preview mode to see image](../screenshots/6-1-3-output-newX.png)


1. Mark your work as complete, commit and push your commit, before going on to the Bonus.


