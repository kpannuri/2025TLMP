# Lab 7-2: View a Webpage

## Objectives

* View the use of JS on a webpage


## Steps

1. Open the following file in this folder in the editor `js-example.html`.

1. View the code and right-click on the code to choose Open in Browser. 

    ![Open in Preview mode to see this image](../screenshots/2-1-open.png)

1. confirm you see output similar to the following in the browser

    ![Open in Preview mode to see this image](../screenshots/7-2-2-browser.png)

1. Notice the code that is generating this outout in the JS.  
* What is the name of the function that contains the logic to update the page?
* what triggers the calling of this function?



