# Chapter 4: Lab 1 - VS Code & Markdown

## Objectives

* Practice with VS Code & extensions
* Practice with markdown files
* Create WIP directory used during class
* Practice committing in your own branch

## Terms

* Throughout the course the terms **folder** and **directory** are used interchangeable.
* You may see references to Enter key or Return key. These are the same intention, **Enter** is usually found on Windows and **Return** on Macs.

## Part 1 Observe VS Code Organization

It is quite common to need multiple windows and panes open at one time in VS Code, in order to compare files, read instructions, compare commit histories, read helpful instructions for projects and more.
 
Whether you primarily end up working on a small laptop screen or large 4k monitor, you want to be able to comfortably use VS Code and multiple file tabs - watch each of these animations, and revisit this section if you ever need help.

* Preview mode for readme.md markdown files is required to see the images and animations. If you want to increase an image size, you can drag the vertical separator, as shown in the following animation.

    ![Open In Preview Mode to see animation](screenshots/1-9-make-img-bigger.gif)

* The Sidebar Panes are toggles. Click to hide the active panel, or click and drag the vertical bar all the way left, when you want to have more space.

    ![Open In Preview Mode to see animation](screenshots/1-7-hide-pane.gif)


* Our markdown files are set to use split screen automatically because of the extension Auto Open. If the extension ever isn't working, or you have closed Preview Mode, you can use a method discussed in the lecture/on slides. Here is an example of using the Open Preview icon...

    ![Open In Preview Mode to see image](screenshots/1-9a-go-split-screen.gif)

* Make sure you are in split screen mode viewing this document in both edit mode and preview mode.  With a markdown file open in both Edit mode and Preview mode, notice that if you scroll in one, the other scrolls as well. It does not always match up well when images are used.

* In VS Code, while viewing in Preview mode, if you double-click an area of the file, you will be taken to the line to edit what you see in the EDIT VIEW or "source" markdown file for editing.
  

* When you have split screen activated, the **Open Editors** area in the Explorer Pane will show **groups**. You should see this now while reading this readme.md file in VS Code.
  
    ![Open In Preview Mode to see image](screenshots/1-1-3-view-open-editors.png)


* You can drag files between groups to separate them. Either in Editor area, as shown, or under Open Editors as well.

    ![Open In Preview Mode to see animation](screenshots/1-6-drag-tabs.gif)

* When you click a file, it makes it the **active** file. Notice in the animation below, how clicking a file changes the highlight under **Open Editors** to show it is the active file.
  
    ![Open Preview to see animation](./screenshots/1-4-switch-group-activation.gif)

* When you click in Explorer to open a new file, it opens in whichever Group is active. So, when reading the lab directions in Preview mode (with images), activate the other group, before opening, as shown here. That way you can keep reading the directions.

    ![Open Preview to see animation](./screenshots/1-5-open-file.gif)

  
* If you have two screens, even another device like a tablet, you could use GitHub on the other screen to view the README in Preview Mode.

  Make sure you have provided a GitHub username to the instructor, so that you can be added to this course repository - and have access to your work even after class.

  On GitHub you can also hide the sidebar as shown.

    ![Open In Preview Mode to see animation](screenshots/1-9b-github-navigation.gif)

* If you do use GitHub on another device, you cannot copy and paste files. You could use GitHub to view, and then copy paste files from repo in VS Code when directed to. 


  If using a VPN to connect to the Lab Machine - and you want to copy/paste between host and Lab machine,  get familiar with how Guacamole allows for this using Control-Alt-Shift.

    ![Open In Preview Mode to see animation](screenshots/1-9c-guac-copy-paste.gif)


## Closing Tabs / Files

* You can close tabs by either right clicking a tab in the edit pane and getting this menu...

    ![Open In Preview Mode to see image](screenshots/1-1-close-group-from-explorer-pane.png)
   
* Or by using the Explorer pane to right click or close entire group.
    ![Open In Preview Mode to see image](screenshots/close_other_tabs.jpg)

## Copy & Paste

* Keep in mind you can use either Control+C to copy, and Control + V to paste directories, files, and content of files. If connecting to a Lab Machine make sure you are using Chrome, key codes do not always work on other browsers!  You can also right click in VS Code to access the context menu for copy and paste.
    ![Open In Preview Mode to see image](screenshots/1-9h-copy-paste.gif)


## Review The Course Files

* Ensure the Explorer view is visible, listing the files/directories. Recall to click the icon if the view is hidden. 

* Understanding the directories
    * The `/Demos` directory will be used for running demos.
    * The `/Labs` directory will be used for instructions and some libraries for the hands-on exercises you will be doing in class. 

        * It is safe to modify these files, because the Demos and Labs folders are tracked by Git. 
        * If you make and save changes to any of these files, the VS Code source control icon (The Y looking icon in the vertical menu strip) will display a number for each file changed. 
      * ![Open in Preview mode to see image](screenshots/4-source-control.png)
        * You can always revert to the original files by clicking this source control icon, and discarding the changes from one or all files. 
       ![Open in Preview mode to see image](screenshots/5-discard-changes.png)

    * The `z_update_branch` is a batch script you can use to update your repo with demos done during class.

      * make sure you open terminal in the root of your branch as shown. And have no changes in Source Control.   ![Open in Preview mode to see image](screenshots/1-9f-z_branch-your-branch.png)

      * then type z and hit tab to run the update of both your local main and your branch.

      ![Open in Preview mode to see image](screenshots/1-9g-run-z.gif)




## Part 3 - Create a `WIP` directory in your branch

1. Make sure you are looking at the MWD project with the Explorer pane open.

    ![Open in PREVIEW mode to see this image](./screenshots/1-2-1-explorer-pane.png)

    You should see the project name in bold for this course listed. Within this folder you will see the `/Demos` and `/Labs` directories. The name of the folder is what is displayed in bold,  Ex. XXXX-XX-XX-TLMP.

3. Make sure you are in your own branch. Your name should be in the bottom left, not main. 
   
   
4. Now you will create a folder called `WIP-your-name`, to hold your lab work during class - with your first and last name with dashes.  This new folder should be at the same level as `Demos` and `Labs` follow the steps to create this.

   a. Click on the project name so that it becomes outlined as shown. 

    ![Open in PREVIEW mode to see this image](screenshots/1-2-2-name-project-outlined.png)
    
    b. Click the new folder icon and name the new Folder `WIP_` with your name...

    ![Open in PREVIEW mode to see this image](screenshots/1-create-wip-folder.png)

   Remember, if you ever create a folder in the wrong place, you can click and drag it to the correct location.

## Part 4 - Commit and push your code

4. As before, you will commit your changes. Empty folders cannot be committed in Git, so you will create a file in your WIP directory. As shown below:
   1. Make sure you click your WIP folder to select it
   2. Use the new file button
   3. Name the file **myinfo.txt** 

  ![Open in PREVIEW mode to see this image](screenshots\1-2-3-new-file.png)   
   
6. You should now see a number on the Source Control icon in the menu and by clicking on the Source Control menu icon, the active panel will now display `Source Control`. 

    ![Open in PREVIEW mode to see this image](screenshots/1-2-4-source-control-pane.png)


7. In this panel, enter the commit message **Add myinfo.txt**. The idea is to describe the changes declaratively so that if others apply your commits, it changes their environment. You MUST have this commit message. Then you can click the checkmark to do the commit.

    ![Open in PREVIEW mode to see this image](screenshots/1-2-5-message-commit.png)



8.  Once you click that the check mark, the number should then disappear from the Source Control icon. There should then be a button to sync changes. Click this button which pushes your commit to GitHub.

    ![Open in PREVIEW mode to see this image](screenshots/1-2-6-sync-changes.png)

   
10. If you ever miss the sync changes button, you can also click the numbers to the right of your branch name at the bottom to sync changes.

    ![Open in PREVIEW mode to see this image](screenshots/3-push-to-github.png)

1.  Please mark your work as complete. With your name tent card if in a classroom or by using method for online training. (spreadsheet, status symbol, etc.) Then you can move on to the Bonus in the directory `/PracticeBonusProblems/ch1_bonuses`

    ![Open in PREVIEW mode to see this image](screenshots/1-9e-bonus.png)
    
