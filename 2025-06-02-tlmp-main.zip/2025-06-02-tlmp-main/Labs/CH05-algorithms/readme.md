coins
greedy algorothm
https://www.tutorialspoint.com/data_structures_algorithms/greedy_algorithms.htm 


find a piece of furniture to fit
a record player, cd player and receiver.
each 30" wide. Want to have area for holding vinyl records. Budget under $500

