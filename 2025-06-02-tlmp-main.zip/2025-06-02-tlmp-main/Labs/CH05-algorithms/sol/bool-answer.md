# Logic / Puzzle

There are two doors, one leading to a place of treasure and the other to a dragon's lair. Two guardians, one for each door, are present. One of them always speaks the truth, and the other always lies, but you don't know which guardian is which. You are allowed only one question to determine the door that leads to the treasure. What is the question?


Solution: Ask any guardian, "What would the other guardian say if I asked which door leads to the dragon's lair?" Whatever answer you receive points to the door of the dragon's lair. Thus, you choose the opposite door.