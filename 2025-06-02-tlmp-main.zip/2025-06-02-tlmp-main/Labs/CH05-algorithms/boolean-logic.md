# Logic / Puzzle

There are two doors, one leading to a place of treasure and the other to a dragon's lair. Two guardians, one for each door, are present. One of them always speaks the truth, and the other always lies, but you don't know which guardian is which. You are allowed only one question to determine the door that leads to the treasure. What is the question?